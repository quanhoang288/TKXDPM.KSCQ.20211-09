package ecobike.entity;

public enum PAYCONTENT {
    RENT_DEPOSIT, RETURN_PAY, RETURN_REFUND
}
