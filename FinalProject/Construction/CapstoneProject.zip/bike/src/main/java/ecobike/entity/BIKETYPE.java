package ecobike.entity;

public enum BIKETYPE {
    STANDARD_BIKE, STANDARD_E_BIKE, TWIN_BIKE;
}
