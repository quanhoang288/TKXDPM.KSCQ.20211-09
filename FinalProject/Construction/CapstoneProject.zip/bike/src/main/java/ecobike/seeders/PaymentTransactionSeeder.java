//package ecobike.seeders;
//
//public class PaymentTransactionSeeder {
//    public static void main(String[] args) {
//        seed();
//    }
//
//    public static void seed() {
//
//    }
//}
