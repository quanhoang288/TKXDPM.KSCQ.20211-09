package ecobike.subsystem.barcode;

public class BarcodeConverter implements IBarcode{
    @Override
    public String convertBarcode2Id(String barcode) {
        //connect to barcode
        return barcode;
    }
}
