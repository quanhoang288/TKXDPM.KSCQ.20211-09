package ecobike.subsystem.barcode;

public interface IBarcode {
    String convertBarcode2Id(String barcode);
}
