package ecobike.entity;

public enum RENTALSTATUS {
    IN_PROGRESS, PAUSED, FINISHED
}
