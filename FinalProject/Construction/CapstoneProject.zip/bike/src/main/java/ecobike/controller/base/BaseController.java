package ecobike.controller.base;

public class BaseController {

}
